# core/admin.py
from django.contrib import admin
from django.contrib.auth import get_user_model
from .models import (
    Department, Position, Profile,
    Request, RequestStatus, Decision, Approval,
    LeaveRequest, Role,
)

User = get_user_model()


# ---------- Small helpers ----------
@admin.display(description="Departments")
def departments_list(obj):
    return ", ".join(obj.departments.values_list("name", flat=True))


# ---------- Org models ----------
@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    search_fields = ["name"]
    list_display = ["id", "name"]
    ordering = ["name"]


@admin.register(Position)
class PositionAdmin(admin.ModelAdmin):
    search_fields = ["name"]
    list_display = ["id", "name"]
    ordering = ["name"]


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ["id", "user", "employee_id", "role", departments_list, "position"]
    list_filter = ["role", "position", "departments"]
    search_fields = ["user__username", "user__first_name", "user__last_name", "employee_id"]
    filter_horizontal = ["departments"]
    autocomplete_fields = ["user", "position"]
    ordering = ["user__username"]


# ---------- Approvals inline on Request ----------
class ApprovalInline(admin.TabularInline):
    model = Approval
    extra = 0
    readonly_fields = ["decided_by", "decided_role", "decision", "comment", "decided_at"]
    can_delete = False


# ---------- Leave inline on Request (1:1) ----------
class LeaveInline(admin.StackedInline):
    model = LeaveRequest
    extra = 0
    fk_name = "base_request"
    autocomplete_fields = ["replacement"]
    fieldsets = (
        ("Employee Snapshot", {
            "fields": ("position", "personnel_code", "full_name")
        }),
        ("Leave", {
            "fields": ("leave_type", "mode", "daily_from", "daily_to", "duration_days",
                       "hourly_date", "hourly_from", "hourly_to", "replacement",
                       "remaining_monthly_days")
        }),
    )


# ---------- Request admin with inlines ----------
@admin.register(Request)
class RequestAdmin(admin.ModelAdmin):
    list_display = [
        "id", "title", "created_by", "status", "required_user",
        "required_role", "created_at",
    ]
    list_filter = [
        "status", "required_role", ("created_by", admin.RelatedOnlyFieldListFilter),
    ]
    search_fields = ["title", "body", "created_by__username"]
    date_hierarchy = "created_at"
    autocomplete_fields = ["created_by", "required_user"]
    inlines = [LeaveInline, ApprovalInline]
    readonly_fields = ["created_at"]

    # optional: quick view of who can act first
    @admin.display(description="Waiting For")
    def waiting_for(self, obj):
        if obj.required_user:
            return f"user:{obj.required_user}"
        return obj.get_required_role_display()


@admin.register(Approval)
class ApprovalAdmin(admin.ModelAdmin):
    list_display = ["id", "request", "decided_by", "decided_role", "decision", "decided_at"]
    list_filter = ["decision", "decided_role", ("decided_by", admin.RelatedOnlyFieldListFilter)]
    search_fields = ["request__title", "decided_by__username", "comment"]
    date_hierarchy = "decided_at"
    autocomplete_fields = ["request", "decided_by"]
    readonly_fields = ["decided_at"]


# ---------- (Optional) show Profile inline on User admin ----------
# If you want Profile inside the built-in User admin:
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin
from django.contrib.auth.models import User as BuiltinUser

class ProfileInline(admin.StackedInline):
    model = Profile
    can_delete = False
    fk_name = "user"
    filter_horizontal = ["departments"]
    autocomplete_fields = ["position"]
    extra = 0

class UserAdmin(DjangoUserAdmin):
    inlines = [ProfileInline]
    list_display = DjangoUserAdmin.list_display + ("last_login",)

# swap the default User admin
admin.site.unregister(BuiltinUser)
admin.site.register(BuiltinUser, UserAdmin)
