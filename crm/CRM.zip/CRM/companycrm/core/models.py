# core/models.py
from __future__ import annotations

from django.conf import settings
from django.db import models
from django.utils import timezone


# =========================
# Org structure
# =========================
class Department(models.Model):
    name = models.CharField(max_length=100, unique=True)

    class Meta:
        ordering = ["name"]

    def __str__(self) -> str:
        return self.name


class Position(models.Model):
    name = models.CharField(max_length=120, unique=True)

    class Meta:
        ordering = ["name"]

    def __str__(self) -> str:
        return self.name


class Role(models.IntegerChoices):
    # Increasing numbers = increasing seniority
    EMPLOYEE = 1, "Employee"
    MIDDLE = 2, "Middle Management"
    EXECUTIVE = 3, "Executive Management"   # defined for future use (not in current flow)
    BOARD = 4, "Board of Directors"


class Profile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="profile"
    )
    employee_id = models.CharField(max_length=50, unique=True)
    role = models.IntegerField(choices=Role.choices, default=Role.EMPLOYEE)
    position = models.ForeignKey(
        Position, null=True, blank=True, on_delete=models.SET_NULL, related_name="profiles"
    )
    # Middle managers may have multiple departments; employees typically one
    departments = models.ManyToManyField(Department, blank=True, related_name="profiles")

    class Meta:
        ordering = ["user__username"]

    def __str__(self) -> str:
        return f"{self.user.username} ({self.get_role_display()})"


# =========================
# Request + Approvals
# =========================
class RequestStatus(models.TextChoices):
    DRAFT = "DRAFT", "Draft"
    SUBMITTED = "SUBMITTED", "Submitted"
    IN_REVIEW = "IN_REVIEW", "In Review"
    APPROVED = "APPROVED", "Approved"
    REJECTED = "REJECTED", "Rejected"


def _role_of(user) -> int | None:
    prof = getattr(user, "profile", None)
    return getattr(prof, "role", None) if prof else None


class Request(models.Model):
    title = models.CharField(max_length=200)
    body = models.TextField(blank=True)

    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="requests_created"
    )
    created_at = models.DateTimeField(default=timezone.now)

    status = models.CharField(
        max_length=20, choices=RequestStatus.choices, default=RequestStatus.DRAFT
    )

    # Workflow state:
    # - If required_user is set → that specific user (replacement) must act first.
    # - After replacement approves, role-based steps: MIDDLE → BOARD.
    # - required_role must always mirror "who is up next":
    #     * if required_user: it equals that user's role
    #     * else: it equals the role step marker (MIDDLE / BOARD)
    required_user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="requests_waiting_on_me",
        help_text="If set, this specific user must act before role-based approvals.",
    )
    required_role = models.IntegerField(
        choices=Role.choices, default=Role.MIDDLE, help_text="Role required to act next."
    )

    class Meta:
        ordering = ["-created_at"]

    def __str__(self) -> str:
        return f"{self.title} [{self.status}]"

    # --- invariants / helpers ---
    def save(self, *args, **kwargs):
        # Keep required_role in sync with required_user when targeted
        if self.required_user_id:
            r = _role_of(self.required_user)
            if r is not None:
                self.required_role = r
        super().save(*args, **kwargs)

    def is_terminal(self) -> bool:
        """True if the request is already finalized (approved or rejected)."""
        return self.status in (RequestStatus.APPROVED, RequestStatus.REJECTED)

    # --- submission & routing ---
    def submit(self) -> None:
        """
        DRAFT → SUBMITTED.
        Order: Replacement (if present) → MIDDLE → BOARD.
        If a typed payload (e.g., LeaveRequest) has a replacement, that becomes the first actor.
        """
        if self.status != RequestStatus.DRAFT:
            return

        # Prefer already-set required_user, else pull from typed payloads
        replacement = self.required_user
        if not replacement and hasattr(self, "leave") and self.leave.replacement:
            replacement = self.leave.replacement

        if replacement:
            self.required_user = replacement                      # targeted first approver
            self.required_role = _role_of(replacement) or Role.MIDDLE
        else:
            self.required_user = None
            self.required_role = Role.MIDDLE

        self.status = RequestStatus.SUBMITTED
        # save() will re-assert role mirroring
        self.save(update_fields=["required_user", "required_role", "status"])


class Decision(models.TextChoices):
    APPROVE = "APPROVE", "Approve"
    REJECT = "REJECT", "Reject"


class Approval(models.Model):
    request = models.ForeignKey(Request, on_delete=models.CASCADE, related_name="approvals")
    decided_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="approvals_made"
    )
    decided_role = models.IntegerField(choices=Role.choices, null=True, blank=True)
    decision = models.CharField(max_length=10, choices=Decision.choices)
    comment = models.TextField(blank=True)
    decided_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["decided_at"]

    def __str__(self) -> str:
        return f"{self.get_decision_display()} by {self.decided_by} @ {self.decided_at:%Y-%m-%d %H:%M}"

    def save(self, *args, **kwargs):
        # Prevent adding approvals to finalized requests
        if self.request.status in (RequestStatus.APPROVED, RequestStatus.REJECTED):
            from django.core.exceptions import ValidationError
            raise ValidationError("Cannot add approvals to a finalized request.")
        super().save(*args, **kwargs)


# ---------- Workflow helpers ----------
def _share_department(user_a, user_b) -> bool:
    pa = getattr(user_a, "profile", None)
    pb = getattr(user_b, "profile", None)
    if not pa or not pb:
        return False
    a = set(pa.departments.values_list("pk", flat=True))
    b = set(pb.departments.values_list("pk", flat=True))
    return bool(a & b)


def can_user_approve(user, req: Request) -> bool:
    """
    Enforce: Replacement → Middle (same department) → Board.
    - If targeted (required_user): only that user can act.
    - Middle step: only Middle managers (role == MIDDLE) who share a department with creator.
    - Board step: only Board members (role == BOARD).
    - Superusers can always act (optional shortcut).
    """
    if req.is_terminal():
        return False

    if not getattr(user, "is_authenticated", False):
        return False
    if getattr(user, "is_superuser", False):
        return True

    uprof = getattr(user, "profile", None)
    cprof = getattr(req.created_by, "profile", None)
    if not uprof or not cprof:
        return False

    # Replacement step (targeted)
    if req.required_user_id:
        return user.pk == req.required_user_id

    # Role-based steps
    if req.required_role == Role.MIDDLE:
        return (
            uprof.role == Role.MIDDLE
            and _share_department(user, req.created_by)
        )

    if req.required_role == Role.BOARD:
        return uprof.role == Role.BOARD

    # If EXECUTIVE is inserted later, put logic here.
    return False


def apply_decision(user, req: Request, decision: str, comment: str = "") -> None:
    """
    Record a decision and advance the workflow accordingly.
    Replacement → Middle → Board → Approved. Any REJECT finalizes immediately.
    """
    if req.is_terminal():
        raise PermissionError("This request is already finalized.")
    if not can_user_approve(user, req):
        raise PermissionError("You are not allowed to act on this request.")

    Approval.objects.create(
        request=req,
        decided_by=user,
        decided_role=_role_of(user),
        decision=decision,
        comment=comment or "",
    )

    # Any REJECT immediately finalizes
    if decision == Decision.REJECT:
        req.status = RequestStatus.REJECTED
        req.required_user = None  # clear any targeted approver
        req.save(update_fields=["status", "required_user"])
        return

    # APPROVE path
    if req.required_user_id:
        # Replacement approved → clear targeted step → go to Middle (role marker)
        req.required_user = None
        req.required_role = Role.MIDDLE
        req.status = RequestStatus.IN_REVIEW
        req.save(update_fields=["required_user", "required_role", "status"])
        return

    if req.required_role == Role.MIDDLE:
        # Middle approved → Board (role marker)
        req.required_role = Role.BOARD
        req.status = RequestStatus.IN_REVIEW
        req.save(update_fields=["required_role", "status"])
        return

    if req.required_role == Role.BOARD:
        # Final approval
        req.status = RequestStatus.APPROVED
        req.save(update_fields=["status"])
        return


# =========================
# Leave request (typed payload)
# =========================
class LeaveType(models.TextChoices):
    PAID = "PAID", "Paid Leave"
    SICK = "SICK", "Sick Leave"
    EMERGENCY = "EMERGENCY", "Emergency Leave"


class LeaveMode(models.TextChoices):
    DAILY = "DAILY", "Daily"
    HOURLY = "HOURLY", "Hourly"


class LeaveRequest(models.Model):
    # Link to the generic Request (1:1 keeps audit/approvals)
    base_request = models.OneToOneField(
        Request, on_delete=models.CASCADE, related_name="leave"
    )

    # Snapshot of identity at the time of request
    position = models.CharField(max_length=100, blank=True)
    personnel_code = models.CharField(max_length=50, blank=True)
    full_name = models.CharField(max_length=150, blank=True)

    leave_type = models.CharField(max_length=12, choices=LeaveType.choices)
    mode = models.CharField(max_length=8, choices=LeaveMode.choices)

    # DAILY fields
    daily_from = models.DateField(null=True, blank=True)
    daily_to = models.DateField(null=True, blank=True)
    duration_days = models.DecimalField(max_digits=4, decimal_places=1, null=True, blank=True)

    # HOURLY fields
    hourly_date = models.DateField(null=True, blank=True)
    hourly_from = models.TimeField(null=True, blank=True)
    hourly_to = models.TimeField(null=True, blank=True)

    # Replacement (first approver; must be validated in forms to be same layer & dept policy)
    replacement = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="leave_replacements",
        help_text="The person who will cover; they approve first.",
    )

    # Optional HR box
    remaining_monthly_days = models.DecimalField(max_digits=4, decimal_places=1, null=True, blank=True)

    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self) -> str:
        return f"Leave #{self.pk} ({self.get_leave_type_display()} · {self.get_mode_display()})"

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.mode == LeaveMode.DAILY:
            if not (self.daily_from and self.daily_to):
                raise ValidationError("Daily leave requires 'from' and 'to' dates.")
        if self.mode == LeaveMode.HOURLY:
            if not (self.hourly_date and self.hourly_from and self.hourly_to):
                raise ValidationError("Hourly leave requires date, from, and to times.")


# =========================
# Signals: auto-create Profile
# =========================
from django.db.models.signals import post_save
from django.dispatch import receiver


@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def create_profile_for_user(sender, instance, created, **kwargs):
    """
    Auto-create a Profile for each new user if missing.
    Default role = EMPLOYEE; employee_id = "U<pk>".
    """
    if created:
        Profile.objects.get_or_create(
            user=instance,
            defaults={
                "employee_id": f"U{instance.pk}",
                "role": Role.EMPLOYEE,
            },
        )
